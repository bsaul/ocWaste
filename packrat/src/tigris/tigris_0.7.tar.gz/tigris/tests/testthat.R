library(testthat)
library(tigris)

test_check("tigris")
